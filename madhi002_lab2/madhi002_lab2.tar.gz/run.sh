mvn package
java -cp target/madhi002_lab2-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.madhi002.App 3 20 5
java -cp target/madhi002_lab2-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.madhi002.App 3 20 3,5
java -cp target/madhi002_lab2-1.0-SNAPSHOT.jar edu.ucr.cs.cs167.madhi002.App 3 20 3v5
