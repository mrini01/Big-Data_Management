# Lab 2

## Student information

* Full name: Mrinisha Adhikari
* E-mail: madhi002@ucr.edu
* UCR NetID: madhi002
* Student ID: 862309931

## Answers

- **(Q1)** Which of the following is the right way to call the `IsEven` function.

    - IsEven(5)
    - IsEven.apply(5)
    + new IsEven().apply(5)  -CORRECT OPTION-

new IsEven().apply(5) is correct way to call 'IsEven' function.

- **(Q2)** Did the program compile?
No, the program did not compile. 

- **(Q3)** If it does not work, what is the error message you get?
Error message that I got:
java: local variables referenced from a lambda expression must be final or effectively final
